#include "test_support.hpp"
#include "cppunivariate/distributions/binom/mle.hpp"
#include "cppunivariate/distributions/binom/dpqr.hpp"
#include "cppunivariate/distributions/rng_std.hpp"
#include <cmath>
#include <limits>
#include <vector>
namespace dist = cppunivariate::distributions;
#define D_APPROX(x) doctest::Approx(x).epsilon(mltest::kTol)
#define D_APPROX_FD(x) doctest::Approx(x).epsilon(mltest::kFdTol)
namespace {
 std::vector<int> as_ints(const std::vector<double> &v) {
   std::vector<int> out;
   for (double x : v) out.push_back(static_cast<int>(x));
   return out;
 }
 cppunivariate::ispan as_ispan(const std::vector<int> &v) { return {v.data(), v.size()}; }
 }
 TEST_CASE("binom") {
  auto g = mltest::load_distribution_golden("binom");
  auto v = as_ints(g.data);
  // size_or_nan: estimate size when NaN. Wrapper passes NaN by default.
  auto r = cppunivariate::binom_mle(as_ispan(v),
                             std::numeric_limits<double>::quiet_NaN(),
                             mltest::kFitTol, mltest::kFitMaxit);
  CHECK(r.size == doctest::Approx(g.estimates.at("size")).epsilon(mltest::kGolden_binom).scale(0));
  CHECK(r.prob == doctest::Approx(g.estimates.at("prob")).epsilon(mltest::kGolden_binom).scale(0));
  CHECK(r.logLik == doctest::Approx(g.logLik).epsilon(mltest::kGolden_binom).scale(0));
}

TEST_CASE("binom probability boundaries") {
  const double nan = std::numeric_limits<double>::quiet_NaN();
  for (const double size : {nan, 5.0}) {
    const std::vector<int> v{5, 5, 5};
    const auto r = cppunivariate::binom_mle(as_ispan(v), size, mltest::kFitTol, mltest::kFitMaxit);
    REQUIRE(r.status == cppunivariate::BinomStatus::Ok);
    CHECK(r.size == 5.0);
    CHECK(r.prob == 1.0);
    CHECK(r.logLik == 0.0);
  }
  for (const double size : {nan, 0.0, 5.0}) {
    const std::vector<int> v{0, 0, 0};
    const auto r = cppunivariate::binom_mle(as_ispan(v), size, mltest::kFitTol, mltest::kFitMaxit);
    REQUIRE(r.status == cppunivariate::BinomStatus::Ok);
    CHECK(r.size == (std::isnan(size) ? 0.0 : size));
    CHECK(r.prob == 0.0);
    CHECK(r.logLik == 0.0);
  }
}

TEST_CASE("binom dpqr: trivial trial size, CDF endpoints") {
  // Bernoulli(0.5): P(X=0) = P(X=1) = 0.5.
  CHECK(dist::dbinom(0.0, 1.0, 0.5, false) == doctest::Approx(0.5));
  CHECK(dist::dbinom(1.0, 1.0, 0.5, false) == doctest::Approx(0.5));
  // CDF endpoint.
  CHECK(dist::pbinom(10.0, 10.0, 0.3, true, false) == doctest::Approx(1.0));
  // Round-trip.
  const double k = dist::qbinom(0.7, 20.0, 0.4, true, false);
  CHECK(dist::pbinom(k, 20.0, 0.4, true, false) >= 0.7);
}

// Independent high-precision oracle; see quality/truth.py.
// Extreme-tail and quantile references are independent of the C++ backend.
TEST_CASE("binom: d/p/q/r against the truth table") {
  mltest::check_dpqr_truth("binom",
      [](double x, const std::vector<double> &p, bool log) { return cppunivariate::distributions::dbinom(x, p[0], p[1], log); },
      [](double x, const std::vector<double> &p, bool lower, bool log) { return cppunivariate::distributions::pbinom(x, p[0], p[1], lower, log); },
      [](double x, const std::vector<double> &p, bool lower, bool log) { return cppunivariate::distributions::qbinom(x, p[0], p[1], lower, log); },
      [](cppunivariate::distributions::StdRng<> &rng, const std::vector<double> &p) { return cppunivariate::distributions::rbinom(rng, p[0], p[1]); });
}

TEST_CASE("binom: free size brackets the integer profile maximum") {
 const double nan=std::numeric_limits<double>::quiet_NaN();
 for (auto x : {std::vector<int>{2,6,6},std::vector<int>{1,2,3,4,5},std::vector<int>{1,3,3,4}}) {
   const auto f=cppunivariate::binom_mle(as_ispan(x),nan,1e-10,100);
   REQUIRE(f.status==cppunivariate::BinomStatus::Ok);
   for(int k=*std::max_element(x.begin(),x.end()); k<=500; ++k)
     CHECK(f.logLik>=cppunivariate::binom_mle(as_ispan(x),k,1e-10,100).logLik-1e-10);
 }
 const std::vector<int> x{2,6,6};
 CHECK(cppunivariate::binom_mle(as_ispan(x),nan,1e-10,100).size==13);
}

TEST_CASE("binom: held probability profiles every integer and endpoint") {
 const double nan=std::numeric_limits<double>::quiet_NaN();
 for(auto x:{std::vector<int>{1,2,2,4},std::vector<int>{0,0},std::vector<int>{3,3}}) {
  const auto f=cppunivariate::binom_mle({x.data(),x.size()},nan,1e-10,100,.4);
  REQUIRE(f.status==cppunivariate::BinomStatus::Ok);CHECK(f.prob==.4);
  for(int k=*std::max_element(x.begin(),x.end());k<100;++k) {
   const auto o=cppunivariate::binom_mle({x.data(),x.size()},k,1e-10,100,.4);
   CHECK(f.logLik>=o.logLik-1e-10);
  }
 }
 const std::vector<int> x{2,2};
 CHECK(cppunivariate::binom_mle({x.data(),x.size()},nan,1e-10,100,1).size==2);
 CHECK(cppunivariate::binom_mle({x.data(),x.size()},nan,1e-10,100,0).status==cppunivariate::BinomStatus::InvalidInput);
}


TEST_CASE("binom: extreme tails and discrete support") {
  // mpmath snippet (parameters converted from the binary64 inputs):
  // from mpmath import *; mp.dps=500
  // n=mpf(9.0); p=mpf(0.5)
  // d=lambda k:binomial(n,k)*p**k*(1-p)**(n-k); S=lambda k:fsum(d(j) for j in range(int(k)+1,int(n)+1))
  // print(log(d(mpf(4.0)))); print(log(S(mpf(4.0))))
  // lo,hi=0,9
  // while hi-lo>1:
  //     k=(lo+hi)//2
  //     if log(S(k))>-10000: lo=k
  //     else: hi=k
  // print(hi)
  CHECK(cppunivariate::distributions::dbinom(4.0, 9.0, 0.5, true) == doctest::Approx(-1.4020427180880297).epsilon(1e-10));
  CHECK(cppunivariate::distributions::pbinom(4.0, 9.0, 0.5, false, true) == doctest::Approx(-0.6931471805599453).epsilon(1e-10));
  CHECK(cppunivariate::distributions::qbinom(-10000, 9.0, 0.5, false, true) == 9.0);
  CHECK(cppunivariate::distributions::dbinom(0.5, 9.0, 0.5, false) == 0);
}

TEST_CASE("binom: exact and rounded half probabilities") {
  // mp.dps=100; print(fsum(binomial(9,k) for k in range(5,10))/2**9)
  // Exactly 0.5, including the upper-tail equality at x=4.
  CHECK(cppunivariate::distributions::qbinom(0.5,9,0.5,false,false)==4);
  CHECK(cppunivariate::distributions::qbinom(-0.6931471805599453,9,0.5,true,true)==5);
}

// TASK-85/87: the free-size search used to hard-fail once its bracket
// reached 1,000,000, regardless of how much of the iteration budget
// (`maxit`) was left. These samples (one 0, v copies of v) push x_bar
// just barely below the population variance -- DeRiggi (1983) still
// guarantees a unique finite maximizer there -- and have a true optimal
// size far past that old cap. See test.R for an independent R-side
// lgamma profile cross-check; here we check self-consistency (status,
// no cap, and the found size beating coarse alternatives) and that the
// iteration budget, not a magnitude, is the only limit.
TEST_CASE("binom: free size has no magnitude cap at very large optimal sizes") {
  for (long long v : {1000LL, 5000LL}) {
    std::vector<int> x;
    x.reserve(static_cast<std::size_t>(v) + 1);
    x.push_back(0);
    for (long long i = 0; i < v; ++i) x.push_back(static_cast<int>(v));
    const auto f = cppunivariate::binom_mle(as_ispan(x), std::numeric_limits<double>::quiet_NaN(), 1e-10, 1000);
    REQUIRE(f.status == cppunivariate::BinomStatus::Ok);
    CHECK(f.size > 1e5);
    // Coarse, far-off alternatives are unambiguously worse (the profile
    // is far too flat near the true optimum itself for an adjacent- or
    // even nearby-integer comparison to be numerically meaningful at
    // this scale; see the report).
    for (double factor : {0.01, 0.1, 0.5, 2.0, 10.0, 100.0}) {
      const double alt_size = std::max<double>(v, std::floor(f.size * factor));
      const auto alt = cppunivariate::binom_mle(as_ispan(x), alt_size, 1e-10, 1000);
      REQUIRE(alt.status == cppunivariate::BinomStatus::Ok);
      CHECK(f.logLik + 1e-6 >= alt.logLik);
    }
    // The pre-TASK-85/87 cap: still dramatically worse once v is large
    // enough that it actually bites.
    if (f.size > 1e6) {
      const auto at_cap = cppunivariate::binom_mle(as_ispan(x), 1e6, 1e-10, 1000);
      REQUIRE(at_cap.status == cppunivariate::BinomStatus::Ok);
      CHECK(f.logLik > at_cap.logLik + 1e-3);
    }
  }
}

TEST_CASE("binom: free size search does not hang at an astronomically large optimum") {
  // v = 1e6 pushes the true optimal size to roughly 3e11: the search
  // must terminate (within a generous but fixed iteration budget -- the
  // bracket doubles, so this is O(log2(size)), never a function of a
  // hardcoded magnitude) and land far above any size the old 1e6 cap
  // could reach.
  const long long v = 1000000LL;
  std::vector<int> x;
  x.reserve(static_cast<std::size_t>(v) + 1);
  x.push_back(0);
  for (long long i = 0; i < v; ++i) x.push_back(static_cast<int>(v));
  const auto f = cppunivariate::binom_mle(as_ispan(x), std::numeric_limits<double>::quiet_NaN(), 1e-10, 1000);
  REQUIRE(f.status == cppunivariate::BinomStatus::Ok);
  CHECK(f.size > 1e8);
  const auto at_cap = cppunivariate::binom_mle(as_ispan(x), 1e6, 1e-10, 1000);
  REQUIRE(at_cap.status == cppunivariate::BinomStatus::Ok);
  CHECK(f.logLik > at_cap.logLik + 1e6);
}

TEST_CASE("binom: free size search budget is iterations, not a magnitude cap") {
  // A tiny iteration budget fails cleanly (IterationFailure, not a
  // wrong answer) rather than silently returning a capped/truncated
  // size; the same sample succeeds once the budget is large enough for
  // its O(log2(size)) requirement, with no change needed to any fixed
  // magnitude.
  const long long v = 5000LL;
  std::vector<int> x;
  x.reserve(static_cast<std::size_t>(v) + 1);
  x.push_back(0);
  for (long long i = 0; i < v; ++i) x.push_back(static_cast<int>(v));
  const auto starved = cppunivariate::binom_mle(as_ispan(x), std::numeric_limits<double>::quiet_NaN(), 1e-10, 2);
  CHECK(starved.status == cppunivariate::BinomStatus::IterationFailure);
  const auto ok = cppunivariate::binom_mle(as_ispan(x), std::numeric_limits<double>::quiet_NaN(), 1e-10, 1000);
  CHECK(ok.status == cppunivariate::BinomStatus::Ok);
}

TEST_CASE("binom attained point sampler ignores zero uniform") {
  // At success probability one the (possibly truncated) law is delta_size.
  struct ZeroRng { double runif(double,double) { return 0; } } rng;
  CHECK(cppunivariate::distributions::rbinom(rng,5,1)==5);
}

TEST_CASE("binom: TASK-132 negative counts never report success") {
  const std::vector<int> data{-1,-2,-3};
  for (double size : {double(NAN),10.0})
    CHECK(cppunivariate::binom_mle(cppunivariate::ispan{data.data(),data.size()},size,1e-8,200).status == cppunivariate::BinomStatus::InvalidInput);
}

TEST_CASE("binom: structured stop payloads") {
  const std::vector<int> x{0,0,6};
  const auto r=cppunivariate::binom_mle({x.data(),x.size()},NAN,1e-8,100);
  REQUIRE(r.status==cppunivariate::BinomStatus::Underdispersed);
  REQUIRE(r.stop_detail.limit_coef.size()==1);
  CHECK(r.stop_detail.limit_coef[0]==2);
  CHECK(r.stop_detail.limit_loglik==doctest::Approx(6*std::log(2.)-6-std::lgamma(7.)));
}

#include "cppunivariate/distributions/binom/dpqr.hpp"
TEST_CASE("binom: quantile search guards and representability") {
  CHECK(mltest::truth_lattice_quantile(cppunivariate::special::binomial_quantile(.5,1e308,.9,true),.5,true,
      [](double x) {return cppunivariate::special::binomial_cdf(x,1e308,.9,true);}));
  CHECK(std::isnan(cppunivariate::distributions::qbinom(.5,1e308,.9,true,false)));
}
