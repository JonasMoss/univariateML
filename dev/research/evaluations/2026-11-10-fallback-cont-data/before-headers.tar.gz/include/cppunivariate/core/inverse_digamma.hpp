// Contract, retained choices, evidence and known numerical limitations:
// dev/research/evaluations/2026-10-31-step7-routines.md (repository root).
// Inverse digamma: solve digamma(y) = x for y.
//
// Asymptotic expansion for very negative x; small Newton refinement
// otherwise. Newton refinements share the caller’s solver-iteration limit
// using the Boost-seam digamma/
// trigamma. Currently used by Kumaraswamy initialization.

#pragma once
#include "work_budget.hpp"

#include "cppunivariate/core/constants.hpp"
#include "../special/special.hpp"

#include <cmath>

namespace cppunivariate {

inline double inverse_digamma_scalar(double x,int maxit=100) {
  maxit=static_cast<int>(solver_budget(maxit));
  constexpr double GAMMA_C = 0.57721566490153286060;
  constexpr double ZETA3_C = 1.2020569031595942854;
  constexpr double PI_C = cppunivariate::pi;
  constexpr double PI_SQ_C = PI_C * PI_C;

  double y, r;
  if (x + GAMMA_C < -30.0) {
    const double t = x + GAMMA_C;
    const double t_inv = 1.0 / t;
    const double t3 = t_inv * t_inv * t_inv;
    y = -t_inv + (PI_SQ_C / 6.0) * t3 + (ZETA3_C / 2.0) * t3 * t_inv;
  } else {
    y = 1.0 / std::log1p(std::exp(-x));
    for (int i = 0; i < maxit; ++i) {
      r = cppunivariate::special::digamma(y) - x;
      if(std::fabs(r)<1e-14)break;
      y -= r / cppunivariate::special::trigamma(y);
    }
  }
  for (int k = 0; k < maxit; ++k) {
    r = cppunivariate::special::digamma(y) - x;
    if (std::fabs(r) < 1e-14) break;
    y -= r / cppunivariate::special::trigamma(y);
  }
  return y;
}

}  // namespace cppunivariate
