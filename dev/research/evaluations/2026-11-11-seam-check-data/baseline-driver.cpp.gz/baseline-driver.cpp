#include <iostream>
#include <iomanip>
#include <algorithm>
#include <cstdlib>
#include "bindings/common/distributions/bbinom/fit.hpp"
#include "cppunivariate/distributions/bbinom/dpqr.hpp"
#include "bindings/common/distributions/beta/fit.hpp"
#include "cppunivariate/distributions/beta/dpqr.hpp"
#include "bindings/common/distributions/betapr/fit.hpp"
#include "cppunivariate/distributions/betapr/dpqr.hpp"
#include "bindings/common/distributions/bhatt/fit.hpp"
#include "cppunivariate/distributions/bhatt/dpqr.hpp"
#include "bindings/common/distributions/binom/fit.hpp"
#include "cppunivariate/distributions/binom/dpqr.hpp"
#include "bindings/common/distributions/bnbinom/fit.hpp"
#include "cppunivariate/distributions/bnbinom/dpqr.hpp"
#include "bindings/common/distributions/burr/fit.hpp"
#include "cppunivariate/distributions/burr/dpqr.hpp"
#include "bindings/common/distributions/cauchy/fit.hpp"
#include "cppunivariate/distributions/cauchy/dpqr.hpp"
#include "bindings/common/distributions/cmb/fit.hpp"
#include "cppunivariate/distributions/cmb/dpqr.hpp"
#include "bindings/common/distributions/cmp/fit.hpp"
#include "cppunivariate/distributions/cmp/dpqr.hpp"
#include "bindings/common/distributions/dgamma/fit.hpp"
#include "cppunivariate/distributions/dgamma/dpqr.hpp"
#include "bindings/common/distributions/dlaplace/fit.hpp"
#include "cppunivariate/distributions/dlaplace/dpqr.hpp"
#include "bindings/common/distributions/dnorm/fit.hpp"
#include "cppunivariate/distributions/dnorm/dpqr.hpp"
#include "bindings/common/distributions/dunif/fit.hpp"
#include "cppunivariate/distributions/dunif/dpqr.hpp"
#include "bindings/common/distributions/dweibull/fit.hpp"
#include "cppunivariate/distributions/dweibull/dpqr.hpp"
#include "bindings/common/distributions/emg/fit.hpp"
#include "cppunivariate/distributions/emg/dpqr.hpp"
#include "bindings/common/distributions/exp/fit.hpp"
#include "cppunivariate/distributions/exp/dpqr.hpp"
#include "bindings/common/distributions/fatigue/fit.hpp"
#include "cppunivariate/distributions/fatigue/dpqr.hpp"
#include "bindings/common/distributions/foldnorm/fit.hpp"
#include "cppunivariate/distributions/foldnorm/dpqr.hpp"
#include "bindings/common/distributions/fpareto/fit.hpp"
#include "cppunivariate/distributions/fpareto/dpqr.hpp"
#include "bindings/common/distributions/frechet/fit.hpp"
#include "cppunivariate/distributions/frechet/dpqr.hpp"
#include "bindings/common/distributions/gamma/fit.hpp"
#include "cppunivariate/distributions/gamma/dpqr.hpp"
#include "bindings/common/distributions/gb2/fit.hpp"
#include "cppunivariate/distributions/gb2/dpqr.hpp"
#include "bindings/common/distributions/ged/fit.hpp"
#include "cppunivariate/distributions/ged/dpqr.hpp"
#include "bindings/common/distributions/genbeta/fit.hpp"
#include "cppunivariate/distributions/genbeta/dpqr.hpp"
#include "bindings/common/distributions/geom/fit.hpp"
#include "cppunivariate/distributions/geom/dpqr.hpp"
#include "bindings/common/distributions/gev/fit.hpp"
#include "cppunivariate/distributions/gev/dpqr.hpp"
#include "bindings/common/distributions/gompertz/fit.hpp"
#include "cppunivariate/distributions/gompertz/dpqr.hpp"
#include "bindings/common/distributions/gpd/fit.hpp"
#include "cppunivariate/distributions/gpd/dpqr.hpp"
#include "bindings/common/distributions/gumbel/fit.hpp"
#include "cppunivariate/distributions/gumbel/dpqr.hpp"
#include "bindings/common/distributions/hcauchy/fit.hpp"
#include "cppunivariate/distributions/hcauchy/dpqr.hpp"
#include "bindings/common/distributions/hnorm/fit.hpp"
#include "cppunivariate/distributions/hnorm/dpqr.hpp"
#include "bindings/common/distributions/ht/fit.hpp"
#include "cppunivariate/distributions/ht/dpqr.hpp"
#include "bindings/common/distributions/huber/fit.hpp"
#include "cppunivariate/distributions/huber/dpqr.hpp"
#include "bindings/common/distributions/hyper/fit.hpp"
#include "cppunivariate/distributions/hyper/dpqr.hpp"
#include "bindings/common/distributions/invburr/fit.hpp"
#include "cppunivariate/distributions/invburr/dpqr.hpp"
#include "bindings/common/distributions/invexp/fit.hpp"
#include "cppunivariate/distributions/invexp/dpqr.hpp"
#include "bindings/common/distributions/invgamma/fit.hpp"
#include "cppunivariate/distributions/invgamma/dpqr.hpp"
#include "bindings/common/distributions/invgauss/fit.hpp"
#include "cppunivariate/distributions/invgauss/dpqr.hpp"
#include "bindings/common/distributions/invparalogis/fit.hpp"
#include "cppunivariate/distributions/invparalogis/dpqr.hpp"
#include "bindings/common/distributions/invpareto/fit.hpp"
#include "cppunivariate/distributions/invpareto/dpqr.hpp"
#include "bindings/common/distributions/invtrgamma/fit.hpp"
#include "cppunivariate/distributions/invtrgamma/dpqr.hpp"
#include "bindings/common/distributions/invweibull/fit.hpp"
#include "cppunivariate/distributions/invweibull/dpqr.hpp"
#include "bindings/common/distributions/kumar/fit.hpp"
#include "cppunivariate/distributions/kumar/dpqr.hpp"
#include "bindings/common/distributions/laplace/fit.hpp"
#include "cppunivariate/distributions/laplace/dpqr.hpp"
#include "bindings/common/distributions/lgamma/fit.hpp"
#include "cppunivariate/distributions/lgamma/dpqr.hpp"
#include "bindings/common/distributions/lgser/fit.hpp"
#include "cppunivariate/distributions/lgser/dpqr.hpp"
#include "bindings/common/distributions/llogis/fit.hpp"
#include "cppunivariate/distributions/llogis/dpqr.hpp"
#include "bindings/common/distributions/lnorm/fit.hpp"
#include "cppunivariate/distributions/lnorm/dpqr.hpp"
#include "bindings/common/distributions/logis/fit.hpp"
#include "cppunivariate/distributions/logis/dpqr.hpp"
#include "bindings/common/distributions/logitnorm/fit.hpp"
#include "cppunivariate/distributions/logitnorm/dpqr.hpp"
#include "bindings/common/distributions/lomax/fit.hpp"
#include "cppunivariate/distributions/lomax/dpqr.hpp"
#include "bindings/common/distributions/lst/fit.hpp"
#include "cppunivariate/distributions/lst/dpqr.hpp"
#include "bindings/common/distributions/naka/fit.hpp"
#include "cppunivariate/distributions/naka/dpqr.hpp"
#include "bindings/common/distributions/nbinom/fit.hpp"
#include "cppunivariate/distributions/nbinom/dpqr.hpp"
#include "bindings/common/distributions/nhyper/fit.hpp"
#include "cppunivariate/distributions/nhyper/dpqr.hpp"
#include "bindings/common/distributions/norm/fit.hpp"
#include "cppunivariate/distributions/norm/dpqr.hpp"
#include "bindings/common/distributions/nsbeta/fit.hpp"
#include "cppunivariate/distributions/nsbeta/dpqr.hpp"
#include "bindings/common/distributions/paralogis/fit.hpp"
#include "cppunivariate/distributions/paralogis/dpqr.hpp"
#include "bindings/common/distributions/pareto/fit.hpp"
#include "cppunivariate/distributions/pareto/dpqr.hpp"
#include "bindings/common/distributions/pareto2/fit.hpp"
#include "cppunivariate/distributions/pareto2/dpqr.hpp"
#include "bindings/common/distributions/pareto3/fit.hpp"
#include "cppunivariate/distributions/pareto3/dpqr.hpp"
#include "bindings/common/distributions/pareto4/fit.hpp"
#include "cppunivariate/distributions/pareto4/dpqr.hpp"
#include "bindings/common/distributions/pig/fit.hpp"
#include "cppunivariate/distributions/pig/dpqr.hpp"
#include "bindings/common/distributions/pois/fit.hpp"
#include "cppunivariate/distributions/pois/dpqr.hpp"
#include "bindings/common/distributions/power/fit.hpp"
#include "cppunivariate/distributions/power/dpqr.hpp"
#include "bindings/common/distributions/rayleigh/fit.hpp"
#include "cppunivariate/distributions/rayleigh/dpqr.hpp"
#include "bindings/common/distributions/sged/fit.hpp"
#include "cppunivariate/distributions/sged/dpqr.hpp"
#include "bindings/common/distributions/sgomp/fit.hpp"
#include "cppunivariate/distributions/sgomp/dpqr.hpp"
#include "bindings/common/distributions/skellam/fit.hpp"
#include "cppunivariate/distributions/skellam/dpqr.hpp"
#include "bindings/common/distributions/slash/fit.hpp"
#include "cppunivariate/distributions/slash/dpqr.hpp"
#include "bindings/common/distributions/sn/fit.hpp"
#include "cppunivariate/distributions/sn/dpqr.hpp"
#include "bindings/common/distributions/snorm/fit.hpp"
#include "cppunivariate/distributions/snorm/dpqr.hpp"
#include "bindings/common/distributions/sstd/fit.hpp"
#include "cppunivariate/distributions/sstd/dpqr.hpp"
#include "bindings/common/distributions/st/fit.hpp"
#include "cppunivariate/distributions/st/dpqr.hpp"
#include "bindings/common/distributions/std/fit.hpp"
#include "cppunivariate/distributions/std/dpqr.hpp"
#include "bindings/common/distributions/tbinom/fit.hpp"
#include "cppunivariate/distributions/tbinom/dpqr.hpp"
#include "bindings/common/distributions/tlambda/fit.hpp"
#include "cppunivariate/distributions/tlambda/dpqr.hpp"
#include "bindings/common/distributions/tnorm/fit.hpp"
#include "cppunivariate/distributions/tnorm/dpqr.hpp"
#include "bindings/common/distributions/tpois/fit.hpp"
#include "cppunivariate/distributions/tpois/dpqr.hpp"
#include "bindings/common/distributions/trgamma/fit.hpp"
#include "cppunivariate/distributions/trgamma/dpqr.hpp"
#include "bindings/common/distributions/triang/fit.hpp"
#include "cppunivariate/distributions/triang/dpqr.hpp"
#include "bindings/common/distributions/unif/fit.hpp"
#include "cppunivariate/distributions/unif/dpqr.hpp"
#include "bindings/common/distributions/weibull/fit.hpp"
#include "cppunivariate/distributions/weibull/dpqr.hpp"
#include "bindings/common/distributions/yulesimon/fit.hpp"
#include "cppunivariate/distributions/yulesimon/dpqr.hpp"
#include "bindings/common/distributions/zeta/fit.hpp"
#include "cppunivariate/distributions/zeta/dpqr.hpp"
#include "bindings/common/distributions/zib/fit.hpp"
#include "cppunivariate/distributions/zib/dpqr.hpp"
#include "bindings/common/distributions/zinb/fit.hpp"
#include "cppunivariate/distributions/zinb/dpqr.hpp"
#include "bindings/common/distributions/zip/fit.hpp"
#include "cppunivariate/distributions/zip/dpqr.hpp"
#include "bindings/common/distributions/zipf/fit.hpp"
#include "cppunivariate/distributions/zipf/dpqr.hpp"
#include "bindings/common/distributions/zmbinom/fit.hpp"
#include "cppunivariate/distributions/zmbinom/dpqr.hpp"
#include "bindings/common/distributions/zmgeom/fit.hpp"
#include "cppunivariate/distributions/zmgeom/dpqr.hpp"
#include "bindings/common/distributions/zmlogarithmic/fit.hpp"
#include "cppunivariate/distributions/zmlogarithmic/dpqr.hpp"
#include "bindings/common/distributions/zmnbinom/fit.hpp"
#include "cppunivariate/distributions/zmnbinom/dpqr.hpp"
#include "bindings/common/distributions/zmpois/fit.hpp"
#include "cppunivariate/distributions/zmpois/dpqr.hpp"
#include "bindings/common/distributions/ztbinom/fit.hpp"
#include "cppunivariate/distributions/ztbinom/dpqr.hpp"
#include "bindings/common/distributions/ztgeom/fit.hpp"
#include "cppunivariate/distributions/ztgeom/dpqr.hpp"
#include "bindings/common/distributions/ztnbinom/fit.hpp"
#include "cppunivariate/distributions/ztnbinom/dpqr.hpp"
#include "bindings/common/distributions/ztpois/fit.hpp"
#include "cppunivariate/distributions/ztpois/dpqr.hpp"
int main(){std::cout<<std::setprecision(17);std::string id,s;unsigned mask;int n,k;
    while(std::cin>>id>>mask>>k>>n){std::vector<double>holds(k),input(n);
    for(double&v:holds){std::cin>>s;v=std::strtod(s.c_str(),nullptr);}for(double&v:input){std::cin>>s;v=std::strtod(s.c_str(),nullptr);}
    if(id=="bbinom"){std::vector<int> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_bbinom(cppunivariate::ispan{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]},umvl_binding::Held{bool(mask&4),holds[2]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"size","alpha","beta"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dbbinom(x, p[0], p[1], p[2], log));}std::cout<<std::endl;continue;}if(id=="beta"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_beta(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"shape1","shape2"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dbeta(x, p[0], p[1], log));}std::cout<<std::endl;continue;}if(id=="betapr"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_betapr(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]},umvl_binding::Held{bool(mask&4),holds[2]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"shape1","shape2","scale"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dbetapr(x, p[0], p[1], p[2], log));}std::cout<<std::endl;continue;}if(id=="bhatt"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_bhatt(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]},umvl_binding::Held{bool(mask&4),holds[2]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"mu","sigma","a"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dbhatt(x, p[0], p[1], p[2], log));}std::cout<<std::endl;continue;}if(id=="binom"){std::vector<int> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_binom(cppunivariate::ispan{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"size","prob"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dbinom(x, p[0], p[1], log));}std::cout<<std::endl;continue;}if(id=="bnbinom"){std::vector<int> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_bnbinom(cppunivariate::ispan{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]},umvl_binding::Held{bool(mask&4),holds[2]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"size","alpha","beta"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dbnbinom(x, p[0], p[1], p[2], log));}std::cout<<std::endl;continue;}if(id=="burr"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_burr(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]},umvl_binding::Held{bool(mask&4),holds[2]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"shape1","shape2","scale"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dburr(x, p[0], p[1], p[2], log));}std::cout<<std::endl;continue;}if(id=="cauchy"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_cauchy(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"location","scale"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dcauchy(x, p[0], p[1], log));}std::cout<<std::endl;continue;}if(id=="cmb"){std::vector<int> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_cmb(cppunivariate::ispan{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]},umvl_binding::Held{bool(mask&4),holds[2]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"size","prob","nu"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dcmb(x, p[0], p[1], p[2], log));}std::cout<<std::endl;continue;}if(id=="cmp"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_cmp(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"lambda","nu"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dcmp(x, p[0], p[1], log));}std::cout<<std::endl;continue;}if(id=="dgamma"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_dgamma(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"shape","rate"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::ddgamma(x, p[0], p[1], log));}std::cout<<std::endl;continue;}if(id=="dlaplace"){std::vector<int> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_dlaplace(cppunivariate::ispan{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"location","scale"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::ddlaplace(x, p[0], p[1], log));}std::cout<<std::endl;continue;}if(id=="dnorm"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_dnorm(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"mean","sd"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::ddnorm(x, p[0], p[1], log));}std::cout<<std::endl;continue;}if(id=="dunif"){std::vector<int> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_dunif(cppunivariate::ispan{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"min","max"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::ddunif(x, p[0], p[1], log));}std::cout<<std::endl;continue;}if(id=="dweibull"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_dweibull(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"shape1","shape2"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::ddweibull(x, p[0], p[1], log));}std::cout<<std::endl;continue;}if(id=="emg"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_emg(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]},umvl_binding::Held{bool(mask&4),holds[2]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"mu","sigma","lambda"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::demg(x, p[0], p[1], p[2], log));}std::cout<<std::endl;continue;}if(id=="exp"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_exp(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"rate"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dexp(x, p[0], log));}std::cout<<std::endl;continue;}if(id=="fatigue"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_fatigue(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]},umvl_binding::Held{bool(mask&4),holds[2]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"alpha","beta","mu"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dfatigue(x, p[0], p[1], p[2], log));}std::cout<<std::endl;continue;}if(id=="foldnorm"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_foldnorm(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"mu","sigma"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dfoldnorm(x, p[0], p[1], log));}std::cout<<std::endl;continue;}if(id=="fpareto"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_fpareto(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]},umvl_binding::Held{bool(mask&4),holds[2]},umvl_binding::Held{bool(mask&8),holds[3]},umvl_binding::Held{bool(mask&16),holds[4]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"shape1","shape2","shape3","scale","min"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dfpareto(x, p[0], p[1], p[2], p[3], p[4], log));}std::cout<<std::endl;continue;}if(id=="frechet"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_frechet(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]},umvl_binding::Held{bool(mask&4),holds[2]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"lambda","mu","sigma"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dfrechet(x,p[0],p[1],p[2],log));}std::cout<<std::endl;continue;}if(id=="gamma"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_gamma(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"shape","scale"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dgamma(x, p[0], p[1], log));}std::cout<<std::endl;continue;}if(id=="gb2"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_gb2(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]},umvl_binding::Held{bool(mask&4),holds[2]},umvl_binding::Held{bool(mask&8),holds[3]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"shape1","shape2","shape3","scale"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dgb2(x, p[0], p[1], p[2], p[3], log));}std::cout<<std::endl;continue;}if(id=="ged"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_ged(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]},umvl_binding::Held{bool(mask&4),holds[2]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"mean","sd","nu"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dged(x, p[0], p[1], p[2], log));}std::cout<<std::endl;continue;}if(id=="genbeta"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_genbeta(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]},umvl_binding::Held{bool(mask&4),holds[2]},umvl_binding::Held{bool(mask&8),holds[3]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"shape1","shape2","shape3","scale"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dgenbeta(x, p[0], p[1], p[2], p[3], log));}std::cout<<std::endl;continue;}if(id=="geom"){std::vector<int> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_geom(cppunivariate::ispan{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"prob"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dgeom(x, p[0], log));}std::cout<<std::endl;continue;}if(id=="gev"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_gev(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]},umvl_binding::Held{bool(mask&4),holds[2]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"mu","sigma","xi"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dgev(x, p[0], p[1], p[2], log));}std::cout<<std::endl;continue;}if(id=="gompertz"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_gompertz(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"a","b"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dgompertz(x, p[0], p[1], log));}std::cout<<std::endl;continue;}if(id=="gpd"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_gpd(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]},umvl_binding::Held{bool(mask&4),holds[2]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"mu","sigma","xi"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dgpd(x, p[0], p[1], p[2], log));}std::cout<<std::endl;continue;}if(id=="gumbel"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_gumbel(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"mu","sigma"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dgumbel(x, p[0], p[1], log));}std::cout<<std::endl;continue;}if(id=="hcauchy"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_hcauchy(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"mu","sigma"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dhcauchy(x, p[0], p[1], log));}std::cout<<std::endl;continue;}if(id=="hnorm"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_hnorm(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"mu","sigma"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dhnorm(x, p[0], p[1], log));}std::cout<<std::endl;continue;}if(id=="ht"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_ht(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]},umvl_binding::Held{bool(mask&4),holds[2]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"mu","nu","sigma"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dht(x, p[0], p[1], p[2], log));}std::cout<<std::endl;continue;}if(id=="huber"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_huber(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]},umvl_binding::Held{bool(mask&4),holds[2]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"mu","sigma","epsilon"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dhuber(x, p[0], p[1], p[2], log));}std::cout<<std::endl;continue;}if(id=="hyper"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_hyper(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]},umvl_binding::Held{bool(mask&4),holds[2]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"m","N","k"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dhyper(x, p[0], p[1], p[2], log));}std::cout<<std::endl;continue;}if(id=="invburr"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_invburr(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]},umvl_binding::Held{bool(mask&4),holds[2]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"shape1","shape2","scale"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dinvburr(x, p[0], p[1], p[2], log));}std::cout<<std::endl;continue;}if(id=="invexp"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_invexp(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"scale"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dinvexp(x, p[0], log));}std::cout<<std::endl;continue;}if(id=="invgamma"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_invgamma(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"alpha","beta"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dinvgamma(x, p[0], p[1], log));}std::cout<<std::endl;continue;}if(id=="invgauss"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_invgauss(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"mean","shape"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dinvgauss(x, p[0], p[1], log));}std::cout<<std::endl;continue;}if(id=="invparalogis"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_invparalogis(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"shape","scale"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dinvparalogis(x, p[0], p[1], log));}std::cout<<std::endl;continue;}if(id=="invpareto"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_invpareto(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"shape","scale"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dinvpareto(x, p[0], p[1], log));}std::cout<<std::endl;continue;}if(id=="invtrgamma"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_invtrgamma(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]},umvl_binding::Held{bool(mask&4),holds[2]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"shape1","shape2","scale"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dinvtrgamma(x, p[0], p[1], p[2], log));}std::cout<<std::endl;continue;}if(id=="invweibull"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_invweibull(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"shape","scale"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dinvweibull(x, p[0], p[1], log));}std::cout<<std::endl;continue;}if(id=="kumar"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_kumar(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"a","b"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dkumar(x, p[0], p[1], log));}std::cout<<std::endl;continue;}if(id=="laplace"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_laplace(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"mu","sigma"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dlaplace(x, p[0], p[1], log));}std::cout<<std::endl;continue;}if(id=="lgamma"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_lgamma(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"shapelog","ratelog"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dlgamma(x, p[0], p[1], log));}std::cout<<std::endl;continue;}if(id=="lgser"){std::vector<int> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_lgser(cppunivariate::ispan{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"theta"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dlgser(x, p[0], log));}std::cout<<std::endl;continue;}if(id=="llogis"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_llogis(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"shape","scale"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dllogis(x, p[0], p[1], log));}std::cout<<std::endl;continue;}if(id=="lnorm"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_lnorm(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"meanlog","sdlog"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dlnorm(x, p[0], p[1], log));}std::cout<<std::endl;continue;}if(id=="logis"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_logis(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"location","scale"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dlogis(x, p[0], p[1], log));}std::cout<<std::endl;continue;}if(id=="logitnorm"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_logitnorm(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"mu","sigma"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dlogitnorm(x, p[0], p[1], log));}std::cout<<std::endl;continue;}if(id=="lomax"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_lomax(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"lambda","kappa"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dlomax(x, p[0], p[1], log));}std::cout<<std::endl;continue;}if(id=="lst"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_lst(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]},umvl_binding::Held{bool(mask&4),holds[2]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"mu","sigma","df"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dlst(x, p[0], p[1], p[2], log));}std::cout<<std::endl;continue;}if(id=="naka"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_naka(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"shape","scale"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dnaka(x, p[0], p[1], log));}std::cout<<std::endl;continue;}if(id=="nbinom"){std::vector<int> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_nbinom(cppunivariate::ispan{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"size","prob"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dnbinom(x, p[0], p[1], log));}std::cout<<std::endl;continue;}if(id=="nhyper"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_nhyper(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]},umvl_binding::Held{bool(mask&4),holds[2]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"m","N","r"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dnhyper(x, p[0], p[1], p[2], log));}std::cout<<std::endl;continue;}if(id=="norm"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_norm(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"mean","sd"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dnorm(x, p[0], p[1], log));}std::cout<<std::endl;continue;}if(id=="nsbeta"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_nsbeta(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]},umvl_binding::Held{bool(mask&4),holds[2]},umvl_binding::Held{bool(mask&8),holds[3]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"shape1","shape2","min","max"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dnsbeta(x, p[0], p[1], p[2], p[3], log));}std::cout<<std::endl;continue;}if(id=="paralogis"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_paralogis(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"shape","scale"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dparalogis(x, p[0], p[1], log));}std::cout<<std::endl;continue;}if(id=="pareto"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_pareto(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"a","b"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dpareto(x, p[0], p[1], log));}std::cout<<std::endl;continue;}if(id=="pareto2"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_pareto2(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]},umvl_binding::Held{bool(mask&4),holds[2]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"shape","scale","min"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dpareto2(x, p[0], p[1], p[2], log));}std::cout<<std::endl;continue;}if(id=="pareto3"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_pareto3(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]},umvl_binding::Held{bool(mask&4),holds[2]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"shape","scale","min"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dpareto3(x, p[0], p[1], p[2], log));}std::cout<<std::endl;continue;}if(id=="pareto4"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_pareto4(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]},umvl_binding::Held{bool(mask&4),holds[2]},umvl_binding::Held{bool(mask&8),holds[3]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"shape1","shape2","scale","min"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dpareto4(x, p[0], p[1], p[2], p[3], log));}std::cout<<std::endl;continue;}if(id=="pig"){std::vector<int> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_pig(cppunivariate::ispan{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"mean","shape"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dpig(x, p[0], p[1], log));}std::cout<<std::endl;continue;}if(id=="pois"){std::vector<int> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_pois(cppunivariate::ispan{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"lambda"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dpois(x, p[0], log));}std::cout<<std::endl;continue;}if(id=="power"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_power(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"alpha","beta"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dpower(x, p[0], p[1], log));}std::cout<<std::endl;continue;}if(id=="rayleigh"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_rayleigh(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"sigma"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::drayleigh(x, p[0], log));}std::cout<<std::endl;continue;}if(id=="sged"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_sged(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]},umvl_binding::Held{bool(mask&4),holds[2]},umvl_binding::Held{bool(mask&8),holds[3]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"mean","sd","nu","xi"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dsged(x, p[0], p[1], p[2], p[3], log));}std::cout<<std::endl;continue;}if(id=="sgomp"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_sgomp(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"b","eta"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dsgomp(x, p[0], p[1], log));}std::cout<<std::endl;continue;}if(id=="skellam"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_skellam(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"mu1","mu2"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dskellam(x, p[0], p[1], log));}std::cout<<std::endl;continue;}if(id=="slash"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_slash(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"mu","sigma"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dslash(x, p[0], p[1], log));}std::cout<<std::endl;continue;}if(id=="sn"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_sn(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]},umvl_binding::Held{bool(mask&4),holds[2]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"xi","omega","alpha"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dsn(x, p[0], p[1], p[2], log));}std::cout<<std::endl;continue;}if(id=="snorm"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_snorm(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]},umvl_binding::Held{bool(mask&4),holds[2]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"mean","sd","xi"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dsnorm(x, p[0], p[1], p[2], log));}std::cout<<std::endl;continue;}if(id=="sstd"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_sstd(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]},umvl_binding::Held{bool(mask&4),holds[2]},umvl_binding::Held{bool(mask&8),holds[3]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"mean","sd","nu","xi"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dsstd(x, p[0], p[1], p[2], p[3], log));}std::cout<<std::endl;continue;}if(id=="st"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_st(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]},umvl_binding::Held{bool(mask&4),holds[2]},umvl_binding::Held{bool(mask&8),holds[3]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"xi","omega","alpha","nu"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dst(x,p[0],p[1],p[2],p[3],log));}std::cout<<std::endl;continue;}if(id=="std"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_std(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]},umvl_binding::Held{bool(mask&4),holds[2]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"mean","sd","nu"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dstd(x, p[0], p[1], p[2], log));}std::cout<<std::endl;continue;}if(id=="tbinom"){std::vector<int> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_tbinom(cppunivariate::ispan{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]},umvl_binding::Held{bool(mask&4),holds[2]},umvl_binding::Held{bool(mask&8),holds[3]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"prob","a","b","size"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dtbinom(x, p[0], p[1], p[2], p[3], log));}std::cout<<std::endl;continue;}if(id=="tlambda"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_tlambda(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]},umvl_binding::Held{bool(mask&4),holds[2]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"mu","sigma","lambda"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dtlambda(x, p[0], p[1], p[2], log));}std::cout<<std::endl;continue;}if(id=="tnorm"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_tnorm(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]},umvl_binding::Held{bool(mask&4),holds[2]},umvl_binding::Held{bool(mask&8),holds[3]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"mean","sd","a","b"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dtnorm(x, p[0], p[1], p[2], p[3], log));}std::cout<<std::endl;continue;}if(id=="tpois"){std::vector<int> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_tpois(cppunivariate::ispan{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]},umvl_binding::Held{bool(mask&4),holds[2]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"lambda","a","b"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dtpois(x, p[0], p[1], p[2], log));}std::cout<<std::endl;continue;}if(id=="trgamma"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_trgamma(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]},umvl_binding::Held{bool(mask&4),holds[2]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"shape1","shape2","scale"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dtrgamma(x, p[0], p[1], p[2], log));}std::cout<<std::endl;continue;}if(id=="triang"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_triang(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]},umvl_binding::Held{bool(mask&4),holds[2]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"a","b","c"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dtriang(x, p[0], p[1], p[2], log));}std::cout<<std::endl;continue;}if(id=="unif"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_unif(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"min","max"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dunif(x, p[0], p[1], log));}std::cout<<std::endl;continue;}if(id=="weibull"){std::vector<double> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_weibull(cppunivariate::span{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"shape","scale"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dweibull(x, p[0], p[1], log));}std::cout<<std::endl;continue;}if(id=="yulesimon"){std::vector<int> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_yulesimon(cppunivariate::ispan{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"rho"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dyulesimon(x, p[0], log));}std::cout<<std::endl;continue;}if(id=="zeta"){std::vector<int> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_zeta(cppunivariate::ispan{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"s"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dzeta(x, p[0], log));}std::cout<<std::endl;continue;}if(id=="zib"){std::vector<int> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_zib(cppunivariate::ispan{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]},umvl_binding::Held{bool(mask&4),holds[2]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"size","prob","pi"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dzib(x, p[0], p[1], p[2], log));}std::cout<<std::endl;continue;}if(id=="zinb"){std::vector<int> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_zinb(cppunivariate::ispan{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]},umvl_binding::Held{bool(mask&4),holds[2]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"size","prob","pi"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dzinb(x, p[0], p[1], p[2], log));}std::cout<<std::endl;continue;}if(id=="zip"){std::vector<int> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_zip(cppunivariate::ispan{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"lambda","pi"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dzip(x, p[0], p[1], log));}std::cout<<std::endl;continue;}if(id=="zipf"){std::vector<int> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_zipf(cppunivariate::ispan{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"N","s"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dzipf(x, p[0], p[1], log));}std::cout<<std::endl;continue;}if(id=="zmbinom"){std::vector<int> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_zmbinom(cppunivariate::ispan{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]},umvl_binding::Held{bool(mask&4),holds[2]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"size","prob","p0"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dzmbinom(x, p[0], p[1], p[2], log));}std::cout<<std::endl;continue;}if(id=="zmgeom"){std::vector<int> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_zmgeom(cppunivariate::ispan{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"prob","p0"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dzmgeom(x, p[0], p[1], log));}std::cout<<std::endl;continue;}if(id=="zmlogarithmic"){std::vector<int> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_zmlogarithmic(cppunivariate::ispan{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"prob","p0"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dzmlogarithmic(x, p[0], p[1], log));}std::cout<<std::endl;continue;}if(id=="zmnbinom"){std::vector<int> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_zmnbinom(cppunivariate::ispan{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]},umvl_binding::Held{bool(mask&4),holds[2]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"size","prob","p0"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dzmnbinom(x, p[0], p[1], p[2], log));}std::cout<<std::endl;continue;}if(id=="zmpois"){std::vector<int> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_zmpois(cppunivariate::ispan{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"lambda","p0"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dzmpois(x, p[0], p[1], log));}std::cout<<std::endl;continue;}if(id=="ztbinom"){std::vector<int> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_ztbinom(cppunivariate::ispan{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"size","prob"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dztbinom(x, p[0], p[1], log));}std::cout<<std::endl;continue;}if(id=="ztgeom"){std::vector<int> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_ztgeom(cppunivariate::ispan{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"prob"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dztgeom(x, p[0], log));}std::cout<<std::endl;continue;}if(id=="ztnbinom"){std::vector<int> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_ztnbinom(cppunivariate::ispan{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]},umvl_binding::Held{bool(mask&2),holds[1]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"size","prob"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dztnbinom(x, p[0], p[1], log));}std::cout<<std::endl;continue;}if(id=="ztpois"){std::vector<int> data;for(double v:input)data.push_back(v);
        auto r=umvl_binding::fit_ztpois(cppunivariate::ispan{data.data(),data.size()},umvl_binding::Held{bool(mask&1),holds[0]});
        if(!r.error.empty()){std::cout<<"stop\t"<<r.error<<std::endl;continue;}
        std::vector<double>p;for(const char* name:{"lambda"}){
        auto it=std::find_if(r.estimates.begin(),r.estimates.end(),[&](const auto&v){return v.first==name;});p.push_back(it==r.estimates.end()?NAN:it->second);}
        std::cout<<"ok\t"<<r.logLik;for(double v:p)std::cout<<'\t'<<v;
        for(double x:input){bool log=true;std::cout<<'\t'<<(cppunivariate::distributions::dztpois(x, p[0], log));}std::cout<<std::endl;continue;}}}
